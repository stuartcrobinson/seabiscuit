package analyze.filter_tools;

/** dummy for results handler yVarClass.  */
class futChPct_pfolio {

}
