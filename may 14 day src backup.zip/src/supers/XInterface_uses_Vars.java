/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supers;
import java.io.IOException;
/**
 *
 * @author User
 */
public interface XInterface_uses_Vars {
    public void setXFile_vars() throws IOException;
    
}
