package analyze.conditions;

interface EraConditionInterface {
    boolean isMet(float value);
}
