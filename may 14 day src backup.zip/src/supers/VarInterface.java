package supers;
interface VarInterface {

    /** test javadoc.  include bool doUpdateForNewCurrentPrices*/
    public void calculateData(SuperX x, boolean doUpdateForCurrentPrices);

}
