package analyze.filter_tools;

class FilterFileException extends Exception {

    public FilterFileException(String string) {
	super(string);
    }

}
