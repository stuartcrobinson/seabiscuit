package analyze.conditions;

public abstract class Subcondition implements SubconditionInterface {


}
