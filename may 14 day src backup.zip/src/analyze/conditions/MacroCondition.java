package analyze.conditions;
import java.util.Map;
import analyze.filter_tools.ConditionDetails;


public class MacroCondition {

    public int[] date;

    public Map<String, float[]> data;

    public MacroCondition(ConditionDetails conditionDetails) {
	throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
