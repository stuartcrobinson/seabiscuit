package supers;

interface EraInterface {

}
