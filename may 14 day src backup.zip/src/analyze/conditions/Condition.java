package analyze.conditions;

public class Condition {

    
    
    
}
 